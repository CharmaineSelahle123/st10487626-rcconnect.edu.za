using Microsoft.AspNetCore.Mvc;
using RaceDayMvc.Services;
using Microsoft.AspNetCore.Http; 

namespace RaceDayMvc.Controllers
{
    public class ParticipantController : Controller
    {
        private readonly ApiService _apiService;

        public ParticipantController(ApiService apiService)
        {
            _apiService = apiService;
        }

               private bool IsParticipant()
        {
            return HttpContext.Session.GetString("UserRole") == "Participant";
        }

        // GET: /Participant/Index (Home page showing all events)
        public async Task<IActionResult> Index()
        {
            if (!IsParticipant()) return RedirectToAction("Login", "Account");

            try
            {
                // Fetch upcoming events from the API
                var events = await _apiService.GetAsync<List<dynamic>>("events");
                return View(events);
            }
            catch
            {
                // If API fails, pass an empty list so the page doesn't crash
                return View(new List<dynamic>());
            }
        }

        // GET: /Participant/EventDetails/5
        [HttpGet]
        public async Task<IActionResult> EventDetails(int id)
        {
            if (!IsParticipant()) return RedirectToAction("Login", "Account");

            try
            {
                // Fetch the specific event from the API
                var ev = await _apiService.GetAsync<dynamic>($"events/{id}");
                if (ev == null) return NotFound();

                return View(ev);
            }
            catch
            {
                return RedirectToAction("Index");
            }
        }

        // POST: /Participant/Enrol
        [HttpPost]
        public async Task<IActionResult> Enrol(int eventId, int categoryId)
        {
            if (!IsParticipant()) return RedirectToAction("Login", "Account");

            try
            {
                // Create the payload for the API
                var enrolData = new { EventId = eventId, CategoryId = categoryId };
                
                // Send to API (Assuming your API has an endpoint like api/enrolments)
                var response = await _apiService.PostAsync("enrolments", enrolData);

                if (response.IsSuccessStatusCode)
                {
                    TempData["SuccessMessage"] = "Successfully enrolled!";
                    return RedirectToAction("MyEvents");
                }

                TempData["ErrorMessage"] = "Failed to enrol. You may already be enrolled.";
                return RedirectToAction("EventDetails", new { id = eventId });
            }
            catch
            {
                TempData["ErrorMessage"] = "A system error occurred while trying to enrol.";
                return RedirectToAction("EventDetails", new { id = eventId });
            }
        }

        // GET: /Participant/MyEvents
        [HttpGet]
        public async Task<IActionResult> MyEvents()
        {
            if (!IsParticipant()) return RedirectToAction("Login", "Account");

            try
            {
                // Get the user's Email/Username from Session to filter enrolments
                var userEmail = HttpContext.Session.GetString("UserName"); 

                // Assuming your API has an endpoint like api/enrolments/user/{email}
                var enrolments = await _apiService.GetAsync<List<dynamic>>($"enrolments/user/{userEmail}");
                
                return View(enrolments ?? new List<dynamic>());
            }
            catch
            {
                return View(new List<dynamic>());
            }
        }

        // GET: /Participant/MyResults (Placeholder for next step)
        [HttpGet]
        public IActionResult MyResults()
        {
            if (!IsParticipant()) return RedirectToAction("Login", "Account");
            return View(); // We will build this view next
        }

        // GET: /Participant/Profile (Placeholder for next step)
        [HttpGet]
        public IActionResult Profile()
        {
            if (!IsParticipant()) return RedirectToAction("Login", "Account");
            return View(); // We will build this view next
        }
    }
}