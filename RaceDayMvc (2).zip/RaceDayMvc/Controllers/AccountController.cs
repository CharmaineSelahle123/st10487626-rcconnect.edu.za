using Microsoft.AspNetCore.Mvc;
using RaceDayMvc.Models;
using RaceDayMvc.Services;
using System.Text.Json; 

namespace RaceDayMvc.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApiService _apiService;

        public AccountController(ApiService apiService)
        {
            _apiService = apiService;
        }

        // GET: /Account/Login
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        // POST: /Account/Login
        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            // Call the API
            var response = await _apiService.PostAsync("auth/login", model);

            if (response.IsSuccessStatusCode)
            {
                // Read the response (Assuming API returns { token: "...", role: "Organiser", name: "John" })
                var jsonString = await response.Content.ReadAsStringAsync();
                var loginData = JsonSerializer.Deserialize<LoginResponse>(jsonString, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                // SAVE TO SESSION
                HttpContext.Session.SetString("JwtToken", loginData.Token);
                HttpContext.Session.SetString("UserRole", loginData.Role);
                HttpContext.Session.SetString("UserName", loginData.Name ?? model.Email);

                // Redirect based on role
                if (loginData.Role == "Organiser")
                {
                    return RedirectToAction("Dashboard", "Organiser");
                }
                else
                {
                    return RedirectToAction("Index", "Participant");
                }
            }

            ModelState.AddModelError("", "Invalid email or password.");
            return View(model);
        }

        // GET: /Account/Register
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        // POST: /Account/Register
        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            // Call the API to register
            var response = await _apiService.PostAsync("auth/register", model); // Adjust endpoint if needed

            if (response.IsSuccessStatusCode)
            {
                // If registration is successful, redirect to login
                return RedirectToAction("Login");
            }

            ModelState.AddModelError("", "Registration failed. Email might already be in use.");
            return View(model);
        }

        // GET: /Account/Logout
        public IActionResult Logout()
        {
            HttpContext.Session.Clear(); 
            return RedirectToAction("Login");
        }
    }

    
    public class LoginResponse
    {
        public string Token { get; set; }
        public string Role { get; set; }
        public string Name { get; set; }
    }
}