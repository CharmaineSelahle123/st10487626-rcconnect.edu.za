using System.Net.Http.Headers;
using System.Text;
using Newtonsoft.Json;

namespace RaceDayMvc.Services
{
    public class ApiService
    {
        private readonly HttpClient _httpClient;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public ApiService(HttpClient httpClient, IHttpContextAccessor httpContextAccessor, IConfiguration config)
        {
            _httpClient = httpClient;
            _httpContextAccessor = httpContextAccessor;
            
           
            _httpClient.BaseAddress = new Uri(config["ApiSettings:BaseUrl"]);
        }

        
        public async Task<T> GetAsync<T>(string endpoint)
        {
            AddTokenToHeader();
            var response = await _httpClient.GetAsync(endpoint);
            response.EnsureSuccessStatusCode(); 
            
            var json = await response.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<T>(json);
        }

       
        public async Task<HttpResponseMessage> PostAsync<T>(string endpoint, T data)
        {
            AddTokenToHeader();
            var json = JsonConvert.SerializeObject(data);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            
            return await _httpClient.PostAsync(endpoint, content);
        }

       
        public async Task<HttpResponseMessage> PostMultipartAsync(string endpoint, MultipartFormDataContent content)
        {
            AddTokenToHeader();
            
            
            return await _httpClient.PostAsync(endpoint, content);
        }

       
        private void AddTokenToHeader()
        {
            var token = _httpContextAccessor.HttpContext?.Session.GetString("JwtToken");
            if (!string.IsNullOrEmpty(token))
            {
                _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            }
        }
    }
}