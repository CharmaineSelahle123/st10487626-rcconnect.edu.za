using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RaceDayApi.Models
{
    public class Result
    {
        [Key]
        public int ResultId { get; set; }

        public int EnrolmentId { get; set; }
        [ForeignKey("EnrolmentId")]
        public EventEnrolment? Enrolment { get; set; }

        public TimeSpan FinishTime { get; set; }
        public int FinishingPosition { get; set; }
    }
}