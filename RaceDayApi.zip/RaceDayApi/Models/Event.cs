using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RaceDayApi.Models
{
    public class Event
    {
        [Key]
        public int EventId { get; set; }

        [Required, MaxLength(150)]
        public string Name { get; set; } = string.Empty;

        public string Description { get; set; } = string.Empty;

        [Required]
        public DateTime Date { get; set; }

        [Required, MaxLength(100)]
        public string Location { get; set; } = string.Empty;

        [Required]
        public double Distance { get; set; }

        [Required, MaxLength(50)]
        public string EventType { get; set; } = string.Empty; // "run", "walk", or "cycle"

        public int OrganiserId { get; set; }
        [ForeignKey("OrganiserId")]
        public User? Organiser { get; set; }

        public ICollection<Category> Categories { get; set; } = new List<Category>();
        public ICollection<EventEnrolment> Enrolments { get; set; } = new List<EventEnrolment>();
    }
}