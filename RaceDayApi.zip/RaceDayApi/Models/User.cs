using System.Collections.Generic;

namespace RaceDayApi.Models
{
    public class User
    {
        public int Id { get; set; }
        public string Username { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;
        public string Role { get; set; } = "Participant";

        // Navigation property for events managed by this user
        public ICollection<Event> ManagedEvents { get; set; } = new List<Event>();
    }
}