using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDayApi.Data;
using RaceDayApi.Models;

namespace RaceDayApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventEnrolmentsController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public EventEnrolmentsController(RaceDayDbContext context)
        {
            _context = context;
        }

        // GET: api/EventEnrolments (Public or Protected depending on preference; let's keep it open or authorized)
        [HttpGet]
        public async Task<ActionResult<IEnumerable<EventEnrolment>>> GetEnrolments()
        {
            return await _context.EventEnrolments.ToListAsync();
        }

        // GET: api/EventEnrolments/5
        [HttpGet("{id}")]
        public async Task<ActionResult<EventEnrolment>> GetEnrolment(int id)
        {
            var enrolment = await _context.EventEnrolments.FindAsync(id);

            if (enrolment == null)
            {
                return NotFound();
            }

            return enrolment;
        }

        // POST: api/EventEnrolments (Protected: Must be logged in to enrol)
        [HttpPost]
        [Authorize]
        public async Task<ActionResult<EventEnrolment>> CreateEnrolment(EventEnrolment enrolment)
        {
            _context.EventEnrolments.Add(enrolment);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetEnrolment), new { id = enrolment.EnrolmentId }, enrolment);
        }

        // DELETE: api/EventEnrolments/5 (Protected: Must be logged in to cancel enrolment)
        [HttpDelete("{id}")]
        [Authorize]
        public async Task<IActionResult> DeleteEnrolment(int id)
        {
            var enrolment = await _context.EventEnrolments.FindAsync(id);
            if (enrolment == null)
            {
                return NotFound();
            }

            _context.EventEnrolments.Remove(enrolment);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool EnrolmentExists(int id)
        {
            return _context.EventEnrolments.Any(e => e.EnrolmentId == id);
        }
    }
}